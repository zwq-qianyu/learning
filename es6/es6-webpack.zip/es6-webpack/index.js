// import test from "./src/test"
// import "./src/const"
// import "./src/scope"
// import "./src/arrow-function"
// import "./src/parameter"
import "./src/proxy"
// test()
